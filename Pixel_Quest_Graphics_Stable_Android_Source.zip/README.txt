PIXEL QUEST — STABLE GRAPHICS BUILD

- index.html: updated game source with persistent camera shake removed and pixel-snapped camera coordinates.
- manifest.webmanifest: install metadata for supported browsers.
- service-worker.js: offline cache source for HTTPS hosting.
- icon.svg: app icon source.

IMPORTANT: This ZIP is NOT an APK. It is a source package for hosting or wrapping into an Android app. To create an APK, use an Android packaging/build tool, then test and sign the APK. The ZIP itself cannot be installed by tapping it.
